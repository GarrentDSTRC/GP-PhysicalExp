linux系统支持CentOS7和Ubuntu16.04两种系统，其余系统未做测试
根据自己linux系统，将相应的linux-xxxx-tar.gz文件解压到当前文件夹


